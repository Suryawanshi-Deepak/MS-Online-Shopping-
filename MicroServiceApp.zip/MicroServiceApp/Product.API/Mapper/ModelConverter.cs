﻿using Product.API.DTO;

namespace Product.API.Mapper
{
    public static class ModelConverter
    {
        public static Product.API.Entities.Product DTOtoModel(ProductDto model)
        {
            return new Product.API.Entities.Product
            {
                Id = model.Id,
                Title = model.Title,
                Description = model.Description,
                Price = model.Price,
                CategoryId = model.CategoryId,
            };
        }
        public static ProductDto ModeltoDto(Product.API.Entities.Product model)
        {
            return new ProductDto
            {
                Id = model.Id,
                Title = model.Title,
                Description = model.Description,
                Price = model.Price,
                CategoryId = model.CategoryId,
            };
        }
    }
}
