﻿using Microsoft.EntityFrameworkCore;
using Product.API.Entities;

namespace Product.API.Data
{
    public class ProductDbContext :DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {

        }
        public DbSet<Product.API.Entities.Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Product.API.Entities.Category>().HasData(
                new Entities.Category
                {
                    Id = 1,
                    Title = "Camera"



                });




            modelBuilder.Entity<Product.API.Entities.Product>().HasData(
                new Entities.Product
                 {
                    Id = 1,
                    Title = "Nikon Digital  Camera  Z 5 kit with extra feature",
                    Price = 1089,
                    Description = "Fcusing system with extra focus with high HD Feature",
                    CategoryId = 1


                });
            modelBuilder.Entity<Product.API.Entities.Product>().HasData(
           new Entities.Product
           {
               Id = 2,
               Title = "Nikon Digital  Camera  Z 3 kit with extra feature",
               Price = 1079,
               Description = "Fcusing extra focus with high HD Feature",
               CategoryId = 1
           });



        }
    }
}
