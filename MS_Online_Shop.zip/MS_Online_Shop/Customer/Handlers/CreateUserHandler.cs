﻿using CustomerAPI.Commands;
using CustomerAPI.Data;
using MediatR;

namespace CustomerAPI.Handlers
{
    public class CreateUserHandler : IRequestHandler<CreateUserCommand, int>
    {
        private readonly CustomerAPIContext _context;
        public CreateUserHandler(CustomerAPIContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {

            _context.Users.Add(request.User);
            await _context.SaveChangesAsync();

            return request.User.UserID;
        }
    }
}
