﻿using CustomerAPI.Models;
using MediatR;

namespace CustomerAPI.Commands
{
    public class GetUserCommand : IRequest<User>
    {
        public int UserId { get; set; }
    }
}
