﻿using MediatR;

namespace CustomerAPI.Commands
{
    public class DeleteUserCommand : IRequest<Unit>
    {
        public int UsertId { get; set; }
    }
}
