﻿using CustomerAPI.Models;
using MediatR;

namespace CustomerAPI.Commands
{
    public class UpdateUserCommand : IRequest<Unit>
    {
        public int UserId { get; set; }
        public User User { get; set; }
    }
}
