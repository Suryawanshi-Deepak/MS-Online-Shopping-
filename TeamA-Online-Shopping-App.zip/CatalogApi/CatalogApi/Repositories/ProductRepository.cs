﻿using CatalogApi.Data;
using CatalogApi.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace CatalogApi.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductDbContext productDbContext;
        public ProductRepository(ProductDbContext _productDbContext)
        {
            productDbContext = _productDbContext;
        }
        public async Task<List<Product>> GetAllProductsAsync()
        {
            return await productDbContext.Products.ToListAsync();
        }

        public async Task<Product> GetProductByIdAsync(Guid productId)
        {
            return await productDbContext.Products.FirstOrDefaultAsync(x => x.ProductId == productId);

        }
        public async Task<Product> AddProductAsync(Product product)
        {
            await productDbContext.AddAsync(product);
            await productDbContext.SaveChangesAsync();
            return product;


        }

        public async Task<Product> DeleteProductAsync(Guid productId)
        {
            var product = await productDbContext.Products.FirstOrDefaultAsync(x => x.ProductId == productId);
            if (product != null)
            {
                productDbContext.Products.Remove(product);
                await productDbContext.SaveChangesAsync();
            }
            return product!;
        }
        public async Task<Product> UpdateProductAsync(Guid productId, Product product)
        {
            var _product = await productDbContext.Products.Where(x => x.ProductId == productId).SingleAsync();

            _product.ProductCategory = product.ProductCategory;
            _product.Description = product.Description;
            _product.Price = product.Price;
            _product.Availability = product.Availability;

            productDbContext.Products.Update(_product);
            await productDbContext.SaveChangesAsync();
            return _product;

        }





    }
}
