﻿using CatalogApi.Models.Domain;

namespace CatalogApi.Repositories
{
    public interface IProductRepository
    {
        Task<Product> AddProductAsync(Product product);
        Task<Product> UpdateProductAsync(Guid productId,Product product);
        Task<Product> DeleteProductAsync(Guid productId);
        Task<List<Product>> GetAllProductsAsync();
        Task<Product> GetProductByIdAsync(Guid productId);
    }
}
