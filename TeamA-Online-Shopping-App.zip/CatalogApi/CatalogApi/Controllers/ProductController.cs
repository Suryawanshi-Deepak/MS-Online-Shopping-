﻿using AutoMapper;
using CatalogApi.Commands;
using CatalogApi.Models.Domain;
using CatalogApi.Models.Dtos.Requests;
using CatalogApi.Models.Dtos.Responses;
using CatalogApi.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CatalogApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IMediator mediator;
        public readonly IMapper mapper;
        public ProductController(IMediator _mediator, IMapper mapper)
        {
            mediator = _mediator;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            // Retrieve all products asynchronously.
            var products = await mediator.Send(new GetAllProductListQuery());
            var productDtos = mapper.Map<List<Product>>(products);
            if (productDtos.Count > 0)
            {
                return Ok(productDtos);
            }
            return Ok(new List<GetProductResponseDto>());
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(Guid id)
        {
            // Retrieve a product by its unique identifier asynchronously.
            var product = await mediator.Send(new GetProductByIdQuery() { ProductId= id });

            if (product == null)
            {
                return NotFound();
            }
            var productDto = mapper.Map<GetProductResponseDto>(product);
            return Ok(productDto);
        }

        [HttpPost]
        public async Task<ActionResult<Product>> CreateProduct([FromBody] AddProductRequestDto AddProductRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var product = mapper.Map<Product>(AddProductRequest);
            var createdProduct = await mediator.Send(new AddProductCommand(
                product.ProductCategory, product.Description, product.Price, product.Availability));
            var createdProductDto = mapper.Map<GetProductResponseDto>(createdProduct);

            return CreatedAtAction(nameof(GetProduct), new { id = createdProductDto.ProductId }, createdProductDto);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult<Product>> UpdateProduct(Guid id, [FromBody] UpdateProductRequestDto updateProductDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingProduct = await mediator.Send(new GetProductByIdQuery() { ProductId = id });

            if (existingProduct == null)
            {
                return NotFound();
            }
            else
            {
                var toBeUpdatedProduct = mapper.Map<Product>(updateProductDTO);
                var updatedProduct = await mediator.Send(new UpdateProductCommand(
                    id, toBeUpdatedProduct.ProductCategory, toBeUpdatedProduct.Description, toBeUpdatedProduct.Price, toBeUpdatedProduct.Availability));
                var updateProductDto = mapper.Map<Product>(updatedProduct);

                return Ok(updateProductDto);

            }

        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Product>> DeleteProduct(Guid id)
        {
            var deletedProduct = await mediator.Send(new DeleteProductCommand() { ProductId = id });
            if (deletedProduct == null)
            {
                return BadRequest(false);
            }
            var deletedProductDto = mapper.Map<GetProductResponseDto>(deletedProduct);
            return Ok(deletedProductDto);
        }

    }
}
