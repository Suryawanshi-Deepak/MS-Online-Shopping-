﻿using System.ComponentModel.DataAnnotations;

namespace CatalogApi.Models.Dtos.Requests
{
    public class AddProductRequestDto
    {
        

        [Required(ErrorMessage = "Category is required.")]
        public string? ProductCategory { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        [MaxLength(255, ErrorMessage = "Description cannot exceed 255 characters.")]
        public string? Description { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0.")]
        public decimal Price { get; set; }

        public bool Availability { get; set; }
    }
}
