﻿using CatalogApi.Models.Domain;
using CatalogApi.Repositories;
using MediatR;

namespace CatalogApi.Queries.Handlers
{
    public class GetProductByIdHandler : IRequestHandler<GetProductByIdQuery, Product>
    {
        private readonly IProductRepository productRepository;

        public GetProductByIdHandler(IProductRepository _productRepository)
        {
            productRepository = _productRepository;
        }

        public async Task<Product> Handle(GetProductByIdQuery request, CancellationToken cancellationToken)
        {
            return await productRepository.GetProductByIdAsync(request.ProductId);
        }
    }
}
