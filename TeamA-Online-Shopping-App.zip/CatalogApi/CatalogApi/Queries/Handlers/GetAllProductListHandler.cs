﻿using CatalogApi.Models.Domain;
using CatalogApi.Repositories;
using MediatR;

namespace CatalogApi.Queries.Handlers
{
    public class GetAllProductListHandler : IRequestHandler<GetAllProductListQuery, List<Product>>
    {
        private readonly IProductRepository productRepository;

        public GetAllProductListHandler(IProductRepository _productRepository)
        {
            productRepository = _productRepository;
        }

        public async Task<List<Product>> Handle(GetAllProductListQuery request, CancellationToken cancellationToken)
        {
            return await productRepository.GetAllProductsAsync();
        }
    }

}
