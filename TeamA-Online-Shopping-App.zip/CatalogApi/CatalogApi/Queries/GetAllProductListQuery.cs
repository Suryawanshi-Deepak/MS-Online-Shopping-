﻿using CatalogApi.Models.Domain;
using MediatR;

namespace CatalogApi.Queries
{
    public class GetAllProductListQuery:IRequest<List<Product>>
    {
    }
}
