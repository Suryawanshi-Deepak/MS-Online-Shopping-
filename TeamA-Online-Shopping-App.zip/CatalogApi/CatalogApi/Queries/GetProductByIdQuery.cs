﻿using CatalogApi.Models.Domain;
using MediatR;

namespace CatalogApi.Queries
{
    public class GetProductByIdQuery:IRequest<Product>
    {
        public Guid ProductId { get; set; }
    }
}
