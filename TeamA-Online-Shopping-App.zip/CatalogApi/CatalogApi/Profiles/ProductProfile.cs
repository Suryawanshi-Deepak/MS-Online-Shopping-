﻿using AutoMapper;
using CatalogApi.Models.Domain;
using CatalogApi.Models.Dtos.Requests;
using CatalogApi.Models.Dtos.Responses;

namespace CatalogApi.Profiles
{
    public class ProductProfile:Profile
    {
        public ProductProfile()
        {
           
            CreateMap<Product, AddProductRequestDto>().ReverseMap();
            CreateMap<Product, GetProductResponseDto>().ReverseMap();
            CreateMap<Product, UpdateProductRequestDto>().ReverseMap();

        }
    }
}
