﻿using CatalogApi.Models.Domain;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace CatalogApi.Commands
{
    public class AddProductCommand : IRequest<Product>
    {
        [Required(ErrorMessage = "Category is required.")]
        public string ProductCategory { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        [MaxLength(255, ErrorMessage = "Description cannot exceed 255 characters.")]
        public string Description { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0.")]
        public decimal Price { get; set; }

        public bool Availability { get; set; }
        public AddProductCommand(string productCategory, string description, decimal price, bool availability)
        {
            ProductCategory = productCategory;
            Description = description;
            Price = price;
            Availability = availability;
        }
    }
}
