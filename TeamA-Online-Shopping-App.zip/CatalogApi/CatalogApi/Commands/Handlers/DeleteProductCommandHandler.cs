﻿using CatalogApi.Models.Domain;
using CatalogApi.Repositories;
using MediatR;

namespace CatalogApi.Commands.Handlers
{
    public class DeleteProductCommandHandler : IRequestHandler<DeleteProductCommand, Product>
    {
        private readonly IProductRepository productRepository;

        public DeleteProductCommandHandler(IProductRepository _productRepository)
        {
            productRepository = _productRepository;
        }
        public async Task<Product> Handle(DeleteProductCommand request, CancellationToken cancellationToken)
        {
           var product=await productRepository.GetProductByIdAsync(request.ProductId);
            return await productRepository.DeleteProductAsync(request.ProductId);


        }
    }
}
