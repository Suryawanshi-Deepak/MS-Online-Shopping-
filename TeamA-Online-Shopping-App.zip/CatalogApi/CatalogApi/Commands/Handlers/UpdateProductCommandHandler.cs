﻿using CatalogApi.Models.Domain;
using CatalogApi.Repositories;
using MediatR;

namespace CatalogApi.Commands.Handlers
{
    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand, Product>
    {
        private readonly IProductRepository productRepository;

        public UpdateProductCommandHandler(IProductRepository _productRepository)
        {
            productRepository = _productRepository;
        }
        public async Task<Product> Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            var product = await productRepository.GetProductByIdAsync(request.ProductId);
            product.ProductCategory = request.ProductCategory;
            product.Description = request.Description;
            product.Price = request.Price;
            product.Availability = request.Availability;
            return await productRepository.UpdateProductAsync(request.ProductId, product);


        }
    }
}
