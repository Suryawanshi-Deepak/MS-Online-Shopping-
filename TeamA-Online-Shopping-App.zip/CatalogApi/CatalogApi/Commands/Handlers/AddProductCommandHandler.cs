﻿using CatalogApi.Models.Domain;
using CatalogApi.Repositories;
using MediatR;

namespace CatalogApi.Commands.Handlers
{
    public class AddProductCommandHandler : IRequestHandler<AddProductCommand, Product>
    {
        private readonly IProductRepository productRepository;

        public AddProductCommandHandler(IProductRepository _productRepository)
        {
            productRepository = _productRepository;
        }
        public async Task<Product> Handle(AddProductCommand request, CancellationToken cancellationToken)
        {
            Product product = new Product
            {
                ProductCategory = request.ProductCategory,
                Description = request.Description,
                Price = request.Price,
                Availability = request.Availability

            };
            return await productRepository.AddProductAsync(product);
        }
    }
}
