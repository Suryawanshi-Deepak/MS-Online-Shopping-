﻿using CatalogApi.Models.Domain;
using MediatR;

namespace CatalogApi.Commands
{
    public class DeleteProductCommand:IRequest<Product>
    {
        public Guid ProductId { get; set; }
    }
}
