﻿using Online_Shopping.Model.Domain;

namespace Online_Shopping.Query.Interface
{
    public interface IQueryRepository
    {
        Task<IEnumerable<User>> GetAllUsersAsync();

        Task<User> GetUsersByIdAsync(Guid userid);

    }
}
