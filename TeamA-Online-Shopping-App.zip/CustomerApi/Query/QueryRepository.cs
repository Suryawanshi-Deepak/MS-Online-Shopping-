﻿using Microsoft.EntityFrameworkCore;
using Online_Shopping.Data;
using Online_Shopping.Model.Domain;
using Online_Shopping.Query.Interface;

namespace Online_Shopping.Query
{
    public class QueryRepository : IQueryRepository

    {

        private readonly UserDbContext userDbContext;
        public QueryRepository(UserDbContext _userDbContext)
        {
            userDbContext = _userDbContext;
        }


        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            return await userDbContext.Users.ToListAsync();
        }

        public async Task<User> GetUsersByIdAsync(Guid userid)
        {

            return await userDbContext.Users.FirstOrDefaultAsync(x => x.UserId == userid);

        }


    }
}
