﻿using System.ComponentModel.DataAnnotations;

namespace Online_Shopping.Model.Domain
{
    public class User
    {
        [Key]
        public Guid UserId { get; set; }
        [Required]
        public string? UserName { get; set; }
        [Required]

        public string? Password { get; set; }
        [Required]
        public string? ContactNo { get; set; }
        [Required]
        public string? UserType { get; set; } // Admin/User
        [Required]
        public string? Address { get; set; }
    }
}
