﻿using Microsoft.EntityFrameworkCore;
using Online_Shopping.Command.Interface;
using Online_Shopping.Data;
using Online_Shopping.Model.Domain;

namespace Online_Shopping.Command
{
    public class CommandRepository : ICommandRepository
    {
        private readonly UserDbContext userDbContext;
        public CommandRepository(UserDbContext _userDbContext)
        {
            userDbContext = _userDbContext;
        }

        public Task<User> AddResultAsync(User user)
        {
            throw new NotImplementedException();
        }

        public async Task<User> AddUserAsync(User user)
        {
            await userDbContext.AddAsync(user);
            await userDbContext.SaveChangesAsync();
            return user;
        }

        public async Task<User> DeleteUserAsync(Guid userid)

        {
            //Guid userIdGuid = Guid.Parse(userid);
            var user = await userDbContext.Users.FirstOrDefaultAsync(x => x.UserId == userid);
            if (user == null)
            {
                return null;
            }
            else
            {
                userDbContext.Remove(user);
                await userDbContext.SaveChangesAsync();
            }
            return user;
        }

        public Task<User> DeleteUsAsync(int userid)
        {
            throw new NotImplementedException();
        }

        public async Task<User> UpdateUserAsync(Guid userid, User user)
        {
            var _user = await userDbContext.Users.SingleAsync(x => x.UserId == userid);
            if (_user == null)
            {
                return null;
            }
            else
            {
                _user.UserName = user.UserName;
                _user.Password = user.Password;
                _user.ContactNo = user.ContactNo;
                _user.UserType = user.UserType;
                _user.Address = user.Address;


                userDbContext.Update(_user);
                await userDbContext.SaveChangesAsync();
            }

            return _user;
        }

      

        public Task<User> DeleteUser1Async(Guid userid)
        {
            throw new NotImplementedException();
        }
    }
}
