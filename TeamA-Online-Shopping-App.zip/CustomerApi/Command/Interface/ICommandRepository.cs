﻿using Online_Shopping.Model.Domain;

namespace Online_Shopping.Command.Interface
{
    public interface ICommandRepository
    {
        Task<User> AddUserAsync(User user);

        Task<User> DeleteUserAsync(Guid userid);

        Task<User> UpdateUserAsync(Guid userid, User user);
    }
}

