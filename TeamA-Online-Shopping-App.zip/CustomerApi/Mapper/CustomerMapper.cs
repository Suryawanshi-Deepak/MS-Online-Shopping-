﻿using AutoMapper;
using Online_Shopping.Model.Domain;
using Online_Shopping.Profiles.Dto;

namespace Online_Shopping.Mapper
{
    public class CustomerMapper : Profile
    {
        public CustomerMapper()
        {
            CreateMap<User,UserDto> ().ReverseMap();
        }
    }
}
