﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Online_Shopping.Command.Interface;
using Online_Shopping.Model.Domain;
using Online_Shopping.Profiles.Dto;
using Online_Shopping.Query.Interface;

namespace Online_Shopping.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IQueryRepository queryRepository;
        private readonly ICommandRepository commandRepository;
        private readonly IMapper mapper;
        public UserController(IQueryRepository _queryRepository, ICommandRepository _commandRepository, IMapper _mapper)
        {
            queryRepository = _queryRepository;
            commandRepository = _commandRepository;
            mapper = _mapper;
        }



        [HttpGet]

        public async Task<IActionResult> GetAllUserAsync()
        {
            var users = await queryRepository.GetAllUsersAsync();

            if (users.Count() == 0)
            {
                return NoContent();
            }
            var userDto = mapper.Map<List<UserDto>>(users);
            return Ok(userDto);
        }


        [HttpGet("UserId")]
        public async Task<ActionResult<User>> GetUsersByIdAsync(Guid userId)
        {
            var id = await queryRepository.GetUsersByIdAsync(userId);
            if (id == null)
            {
                return NotFound();
            }
            var userlDto = mapper.Map<UserDto>(id);
            return Ok(userlDto);

        }

        [HttpPost]

        public async Task<IActionResult> AddUserAsync(User users)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                var UserModel = new User()
                {
                    UserName = users.UserName,
                    Password = users.Password,
                    ContactNo = users.ContactNo,
                    UserType = users.UserType,
                    Address = users.Address,

                };

                users = await commandRepository.AddUserAsync(UserModel);
                var userDto = mapper.Map<UserDto>(users);
                return Ok(userDto);

            }
        }
    

        [HttpDelete("UserId")]
        public async Task<IActionResult> DeleteUserAsync(Guid userId)
        {
            var userData = await commandRepository.DeleteUserAsync(userId);
            if (userData == null)
                return BadRequest();
            else
            {
                var userDto = mapper.Map<UserDto>(userData);
                return Ok(userDto);
            }
        }

        [HttpPut]


        public async Task<IActionResult> UpdateUserAsync(Guid userid, User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                var use = await commandRepository.UpdateUserAsync(userid, user);
                if (user == null)
                {
                    return NoContent();
                }
                else
                {
                    var userDto = mapper.Map<UserDto>(use);
                    return Ok(userDto);
                }
            }
        }
    }
}
