﻿
using ShippingApi.Models.Domain;

namespace CatalogApi.Repositories
{
    public interface IShippingDetailsRepository
    {
        Task<string> AddShippingDetails(ShippingDetail shippingDetail);

        Task<ShippingDetail> GetShippingDetailIdAsync(Guid TrackerId);

    }
}
