﻿
using Microsoft.EntityFrameworkCore;
using ShippingApi.Data;
using ShippingApi.Models.Domain;

namespace CatalogApi.Repositories
{
    public class ShippingDetailsRepository : IShippingDetailsRepository
    {
        private readonly ShippingDbContext shippingDbContext;
        public ShippingDetailsRepository(ShippingDbContext _shippingDbContext)
        {
            shippingDbContext = _shippingDbContext;
        }

        public async Task<string> AddShippingDetails(ShippingDetail shippingDetail)
        {
            try
            {
                await shippingDbContext.AddAsync(shippingDetail);
                await shippingDbContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            return ("Successfully Added Shipping Details");
        }

        public async Task<ShippingDetail> GetShippingDetailIdAsync(Guid TrackerId)
        {

            return await shippingDbContext.ShippingDetails.FirstOrDefaultAsync(x => x.TrackerId == TrackerId);

        }
    }
}
