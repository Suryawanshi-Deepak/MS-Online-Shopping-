﻿using CatalogApi.Repositories;
using MediatR;
using ShippingApi.Models.Domain;

namespace CatalogApi.Queries.Handlers
{
    public class GetShippingDetailsdHandler : IRequestHandler<GetShippingDetailsByIdQuery, ShippingDetail>
    {
        private readonly IShippingDetailsRepository shippingDetailsRepository;

        public GetShippingDetailsdHandler(IShippingDetailsRepository _shippingDetailsRepository)
        {
            shippingDetailsRepository= _shippingDetailsRepository;
        }

        public async Task<ShippingDetail> Handle(GetShippingDetailsByIdQuery request, CancellationToken cancellationToken)
        {
            return await shippingDetailsRepository.GetShippingDetailIdAsync(request.TrackerId);
        }
    }
}
