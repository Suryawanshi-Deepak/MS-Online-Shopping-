﻿
using MediatR;
using ShippingApi.Models.Domain;

namespace CatalogApi.Queries
{
    public class GetShippingDetailsByIdQuery:IRequest<ShippingDetail>
    {
        public Guid TrackerId { get; set; }

    }
}
