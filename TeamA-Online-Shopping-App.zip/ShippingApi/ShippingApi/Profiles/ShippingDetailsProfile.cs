﻿using AutoMapper;
using ShippingApi.Models.Domain;
using ShippingApi.Models.Dtos.Requests;
using ShippingApi.Models.Dtos.Responses;

namespace ShippingApi.Profiles
{
    public class ShippingDetailsProfile : Profile
    {
        public ShippingDetailsProfile()
        {
            CreateMap<ShippingDetail, AddShippingDetailsRequestDto>().ReverseMap();
            CreateMap<ShippingDetail, GetShippingDetailsResponceDto>().ReverseMap();
        }
    }
}
