﻿using Microsoft.EntityFrameworkCore;
using ShippingApi.Models.Domain;

namespace ShippingApi.Data
{
    public class ShippingDbContext : DbContext
    {
        public ShippingDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<ShippingDetail> ShippingDetails { get; set; }
    }
}
