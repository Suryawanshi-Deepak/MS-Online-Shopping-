﻿using AutoMapper;
using CatalogApi.Commands;
using CatalogApi.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using ShippingApi.Models.Domain;
using ShippingApi.Models.Dtos.Requests;
using ShippingApi.Models.Dtos.Responses;


namespace ShippingApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ShippingDetailsController : ControllerBase
    {
        private IMediator mediator;
        public readonly IMapper mapper;

        public ShippingDetailsController(IMediator _mediator, IMapper mapper)
        {
            mediator = _mediator;
            this.mapper = mapper;
        }

        [HttpPost]

        public async Task<ActionResult<ShippingDetail>> AddShoppingDetails([FromBody] AddShippingDetailsRequestDto addShippingDetailsRequestDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var shippingDetails = mapper.Map<ShippingDetail>(addShippingDetailsRequestDto);
            var createdShippingDetails = await mediator.Send(new AddShippingDetailsCommand(
                shippingDetails.UserID, shippingDetails.ProductId, shippingDetails.ContactNo, shippingDetails.NumberOfItems, shippingDetails.AddressDetails));
            if (createdShippingDetails== "Successfully Added Shipping Details")
            {
                return Ok(addShippingDetailsRequestDto);

            }
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred: " + createdShippingDetails);
           
        }

        [HttpGet]
        public async Task<ActionResult<ShippingDetail>> GetProductById(Guid trackerId)
        {
            var shippingdetail=await mediator.Send(new GetShippingDetailsByIdQuery() { TrackerId= trackerId });
            if (shippingdetail == null)
            {
                return NotFound();
            }
            var shippingDetailDto = mapper.Map<GetShippingDetailsResponceDto>(shippingdetail);
            return Ok(shippingDetailDto);

        }
    }
}
