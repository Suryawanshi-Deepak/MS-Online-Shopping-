﻿using System.ComponentModel.DataAnnotations;

namespace ShippingApi.Models.Domain
{
    
    public class ShippingDetail
    {
        [Key]
        [Required(ErrorMessage = "TrackerId is required.")]
        public Guid TrackerId { get; set; }

        [Required(ErrorMessage = "UserID is required.")]
        public Guid UserID { get; set; }

        [Required(ErrorMessage = "ProductId is required.")]
        public Guid ProductId { get; set; }

        [Required(ErrorMessage = "ContactNo is required.")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Invalid ContactNo format.")]
        public string ContactNo { get; set; }
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "NumberOfItems must be a positive value.")]
        public int NumberOfItems { get; set; }
       
        [Required(ErrorMessage = "AddressDetails is required.")]
        public string AddressDetails { get; set; }

        
    }
}

