﻿using CatalogApi.Repositories;
using MediatR;
using ShippingApi.Models.Domain;

namespace CatalogApi.Commands.Handlers
{
    public class AddShippingDetailsCommandHandler : IRequestHandler<AddShippingDetailsCommand, string>
    {
        private readonly IShippingDetailsRepository shippingDetailsRepository;

        public AddShippingDetailsCommandHandler(IShippingDetailsRepository _shippingDetailsRepository)
        {
            shippingDetailsRepository= _shippingDetailsRepository;
        }

        

        public async Task<string> Handle(AddShippingDetailsCommand request, CancellationToken cancellationToken)
        {
            ShippingDetail shippingDetail = new ShippingDetail
            {
                UserID = request.UserID,
                ProductId = request.ProductId,
                ContactNo = request.ContactNo,
                NumberOfItems = request.NumberOfItems,
                AddressDetails = request.AddressDetails

            };
            return await shippingDetailsRepository.AddShippingDetails(shippingDetail);
        }
    }
}
