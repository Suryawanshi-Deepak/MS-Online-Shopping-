﻿using OrderApi.Models.Domain;

namespace OrderApi.Repositories.Interfaces
{
    public interface IOrderRepository
    {
        Task<string> PlaceOrder(Order order);
        Task<Order> UpdateOrder(Order order);
        Task<Order> DeleteOrder(string orderId);
        Task<Order> ConfirmOrder(Guid orderId);
        Task<string> CheckStatus(Guid orderId);
    }
}
