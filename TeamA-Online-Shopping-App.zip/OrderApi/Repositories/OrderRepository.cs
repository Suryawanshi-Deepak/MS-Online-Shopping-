﻿using Microsoft.EntityFrameworkCore;
using OrderApi.Data;
using OrderApi.Models.Domain;
using OrderApi.Repositories.Interfaces;

namespace OrderApi.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly OrderDbContext orderDbContext;
        public OrderRepository(OrderDbContext _orderDbContext) {
            orderDbContext = _orderDbContext;
        }

        public async Task<string> CheckStatus(Guid orderId)
        {
            //orderId = orderId);
            //Guid orderIdGuid = Guid.Parse(orderId);
            var orderData = await orderDbContext.Orders.FirstOrDefaultAsync(x=>x.OrderId==orderId);
            if (orderData == null)
                return "Invalid";
            string? currentStatus = orderData.Status;
            return currentStatus!;
            
        }

        public async Task<Order> ConfirmOrder(Guid orderId)
        {
            var CurrentPlacedOrder = await orderDbContext.Orders.FirstOrDefaultAsync(x => x.OrderId == orderId);
            if (CurrentPlacedOrder != null && CurrentPlacedOrder.Status == "Pending")
            {
                CurrentPlacedOrder.Status = "Confirmed";
                orderDbContext.Orders.Update(CurrentPlacedOrder);
                await orderDbContext.SaveChangesAsync();
                return CurrentPlacedOrder!;
            }
            return null;
        }

        public async Task<Order> DeleteOrder(string orderId)
        {
            Guid orderIdGuid = Guid.Parse(orderId);
            var order = await orderDbContext.Orders.FirstOrDefaultAsync(x=> x.OrderId==orderIdGuid);
            if(order != null&&order.Status!="Confirmed")
            {
                orderDbContext.Orders.Remove(order);
                await orderDbContext.SaveChangesAsync();

            }
            else
            {
                order = null;
            }
            return order!;
        }

        public async Task<string> PlaceOrder(Order order)
        {
            order.Status = "Pending";
            try
            {
                await orderDbContext.Orders.AddAsync(order);
                await orderDbContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            return ("Success");

        }

        public async Task<Order> UpdateOrder(Order order)
        {
            var existingOrder = await orderDbContext.Orders.FirstOrDefaultAsync(x => x.OrderId == order.OrderId);
            if(existingOrder != null&& existingOrder.Status=="Pending")
            {
                existingOrder.ProductId = order.ProductId;
                existingOrder.UserId = order.UserId;
                existingOrder.Status = order.Status;
                existingOrder.Quantity = order.Quantity;
                existingOrder.TotalPrice = order.TotalPrice;
                orderDbContext.Orders.Update(existingOrder);
                await orderDbContext.SaveChangesAsync();
                return order;
            }
            return (null);  
        }
    }
}
