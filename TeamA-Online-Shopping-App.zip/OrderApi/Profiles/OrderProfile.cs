﻿using AutoMapper;
using OrderApi.Models.Domain;
using OrderApi.Models.Dto.Requests;
using OrderApi.Models.Dto.Responses;

namespace OrderApi.Profiles
{
    public class OrderProfile:Profile
    {
        public OrderProfile() { 

            CreateMap<Order,PlaceOrderRequestDto>().ReverseMap();
            CreateMap<Order,UpdatedOrderResponseDto>().ReverseMap();
            CreateMap<Order,UpdateOrderRequestDto>().ReverseMap();
            CreateMap<Order,DeleteOrderResponseDto>().ReverseMap();
            CreateMap<Order,OrderConfirmedResponseDto>().ReverseMap();
        
        }
    }
}
