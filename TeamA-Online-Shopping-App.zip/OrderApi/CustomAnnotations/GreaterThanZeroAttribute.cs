﻿using System.ComponentModel.DataAnnotations;

namespace OrderApi.CustomAnnotations
{
    public class GreaterThanZeroAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is decimal decimalValue)
            {
                return decimalValue >=1;
            }
            return false;
        }
        public override string FormatErrorMessage(string name)
        {
            return $"The value of '{name}' must be greater than zero.";
        }
    }
}
