﻿using AutoMapper;
using MediatR;
using OrderApi.Commands.Requests;
using OrderApi.Models.Domain;
using OrderApi.Models.Dto.Responses;
using OrderApi.Repositories.Interfaces;

namespace OrderApi.Commands.Handlers
{
    public class UpdateOrderCommandHandler : IRequestHandler<UpdateOrderCommandRequest, UpdatedOrderResponseDto>
    {
        private readonly IMapper mapper;
        private readonly IOrderRepository orderRepository;
        public UpdateOrderCommandHandler(IOrderRepository _orderRepository,IMapper _mapper)
        {
            mapper = _mapper;
            orderRepository = _orderRepository;
        }

        public async Task<UpdatedOrderResponseDto> Handle(UpdateOrderCommandRequest request, CancellationToken cancellationToken)
        {
            Order order = new Order()
            {
                OrderId = request.OrderId,
                UserId = request.UserId,
                ProductId = request.ProductId,
                Quantity = request.Quantity,
                TotalPrice = request.TotalPrice,
                Status = "Pending",
            };
            var updatedOrder = await orderRepository.UpdateOrder(order);
            return mapper.Map<UpdatedOrderResponseDto>(updatedOrder);
        }
    }
}
