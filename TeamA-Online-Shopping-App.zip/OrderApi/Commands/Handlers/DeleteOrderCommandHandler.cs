﻿using AutoMapper;
using MediatR;
using OrderApi.Commands.Requests;
using OrderApi.Models.Dto.Responses;
using OrderApi.Repositories.Interfaces;

namespace OrderApi.Commands.Handlers
{
    public class DeleteOrderCommandHandler : IRequestHandler<DeleteOrderCommandRequest, DeleteOrderResponseDto>
    {
        private readonly IMapper mapper;
        private readonly IOrderRepository orderRepository;
        public DeleteOrderCommandHandler(IOrderRepository _orderRepository, IMapper _mapper)
        {
            mapper = _mapper;
            orderRepository = _orderRepository;
        }
        public async Task<DeleteOrderResponseDto> Handle(DeleteOrderCommandRequest request, CancellationToken cancellationToken)
        {
            var deletedOrder = await orderRepository.DeleteOrder(request.OrderId);
            return mapper.Map<DeleteOrderResponseDto>(deletedOrder);
        }
    }
}
