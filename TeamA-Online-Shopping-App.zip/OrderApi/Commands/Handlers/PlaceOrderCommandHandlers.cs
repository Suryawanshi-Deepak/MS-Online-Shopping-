﻿using MediatR;
using OrderApi.Commands.Requests;
using OrderApi.Models.Domain;
using OrderApi.Repositories.Interfaces;

namespace OrderApi.Commands.Handlers
{
    public class PlaceOrderCommandHandlers : IRequestHandler<PlaceOrderCommandRequest, string>
    {
        private readonly IOrderRepository orderRepository;
        public PlaceOrderCommandHandlers(IOrderRepository _orderRepository)
        {
            orderRepository = _orderRepository;
        }
        public async Task<string> Handle(PlaceOrderCommandRequest request, CancellationToken cancellationToken)
        {
            //var order = mapper.Map<Order>(request);
            Order order = new Order()
            {
                UserId = request.UserId,
                ProductId = request.ProductId,
                Quantity = request.Quantity,
                TotalPrice = request.TotalPrice,
            };
            return await orderRepository.PlaceOrder(order);
        }
    }
}
