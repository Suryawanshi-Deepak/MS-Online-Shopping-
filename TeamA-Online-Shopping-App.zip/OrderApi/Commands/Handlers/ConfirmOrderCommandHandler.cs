﻿using AutoMapper;
using MediatR;
using OrderApi.Commands.Requests;
using OrderApi.Models.Dto.Responses;
using OrderApi.Repositories.Interfaces;

namespace OrderApi.Commands.Handlers
{
    public class ConfirmOrderCommandHandler : IRequestHandler<ConfirmOrderCommandRequest, OrderConfirmedResponseDto>
    {
        private readonly IMapper mapper;
        private readonly IOrderRepository orderRepository;
        public ConfirmOrderCommandHandler(IOrderRepository _orderRepository, IMapper _mapper)
        {
            mapper = _mapper;
            orderRepository = _orderRepository;
        }
        public async Task<OrderConfirmedResponseDto> Handle(ConfirmOrderCommandRequest request, CancellationToken cancellationToken)
        {
            var confirmedOrder = await orderRepository.ConfirmOrder(request.OrderId);
            return mapper.Map<OrderConfirmedResponseDto>(confirmedOrder);
        }
    }
}
