﻿using MediatR;
using OrderApi.Models.Dto.Responses;

namespace OrderApi.Commands.Requests
{
    public class ConfirmOrderCommandRequest:IRequest<OrderConfirmedResponseDto>
    {
        public Guid OrderId { get; set; }
        public ConfirmOrderCommandRequest(Guid orderId)
        {
            OrderId = orderId;            
        }
    }
}
