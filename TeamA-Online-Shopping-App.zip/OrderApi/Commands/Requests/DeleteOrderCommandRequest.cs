﻿using MediatR;
using OrderApi.Models.Dto.Responses;

namespace OrderApi.Commands.Requests
{
    public class DeleteOrderCommandRequest:IRequest<DeleteOrderResponseDto>
    {
        public string OrderId { get; set; }
        public DeleteOrderCommandRequest(string orderId)
        {
              OrderId = orderId;
        }
    }
}
