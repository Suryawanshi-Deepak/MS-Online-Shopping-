﻿using MediatR;
using OrderApi.Models.Dto.Responses;

namespace OrderApi.Commands.Requests
{
    public class UpdateOrderCommandRequest:IRequest<UpdatedOrderResponseDto>
    {
        public Guid? UserId { get; set; }
        public Guid? ProductId { get; set; }
        public Int32? Quantity { get; set; }
        public decimal TotalPrice { get; set; }

        public Guid OrderId { get; set; }

        public UpdateOrderCommandRequest(Guid userID, Guid productId, Int32 quantity, decimal totalPrice,Guid orderId)
        {
            UserId = userID;
            ProductId = productId;
            Quantity = quantity;
            TotalPrice = totalPrice;
            OrderId = orderId;
        
        }
    }
}
