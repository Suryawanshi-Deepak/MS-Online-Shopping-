﻿using MediatR;

namespace OrderApi.Commands.Requests
{
    public class PlaceOrderCommandRequest:IRequest<string>
    {
        public Guid UserId { get; set; }
        public Guid ProductId { get; set; }
        public Int32 Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public PlaceOrderCommandRequest(Guid userID, Guid productId, Int32 quantity,decimal totalPrice)
        {
            UserId = userID;
            ProductId = productId;
            Quantity = quantity;
            TotalPrice = totalPrice;
        }
    }
}
