﻿namespace OrderApi.Models.Dto.Responses
{
    public class OrderConfirmedResponseDto
    {
        public Guid? OrderId { get; set; }
        public Guid UserId { get; set; }
        public Guid? ProductId { get; set; }
        public Int32? Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Status { get; set; }
    }
}
