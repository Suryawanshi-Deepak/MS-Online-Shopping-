﻿namespace OrderApi.Models.Dto.Responses
{
    public class DeleteOrderResponseDto
    {
        public Guid? ProductId { get; set; }
        public Int32? Quantity { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
