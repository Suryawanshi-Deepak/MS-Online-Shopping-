﻿using Microsoft.EntityFrameworkCore;
using OrderApi.CustomAnnotations;
using System.ComponentModel.DataAnnotations;

namespace OrderApi.Models.Dto.Requests
{
    public class PlaceOrderRequestDto
    {
        public Guid UserId { get; set; }
        [Required(ErrorMessage = "ProductId is required.")]
        public Guid ProductId { get; set; }
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity Must be greater than 0")]
        public Int32 Quantity { get; set; }
        [Required]
        [Precision(18, 2)]
        [GreaterThanZero]
        public decimal TotalPrice { get; set; }
    }
}
