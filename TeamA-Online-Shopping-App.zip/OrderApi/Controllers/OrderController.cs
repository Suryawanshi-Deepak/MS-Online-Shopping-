﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OrderApi.Commands.Requests;
using OrderApi.Models.Dto.Requests;

namespace OrderApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IMediator mediator;
        public OrderController(IMediator _mediator) { 
            mediator = _mediator;
        }
        [HttpPost]
        public async Task<IActionResult> PlaceOrder([FromBody] PlaceOrderRequestDto placeOrderDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                var newOrder = await mediator.Send(new PlaceOrderCommandRequest(placeOrderDto.UserId,placeOrderDto.ProductId, placeOrderDto.Quantity, placeOrderDto.TotalPrice ));
                if (newOrder == null)
                {
                    return NotFound();
                }
                else if(newOrder !="Success")
                {
                    return NoContent();
                }
                //var jobSkillDTO = mapper.Map<JobSkillDto>(jobSkill);

                //return Ok(jobSkillDTO);
                return Ok("Order Placed Succefully");
            }
        }
        [HttpPut]
        public async Task<IActionResult> UpdateOrder(Guid orderId,[FromBody] UpdateOrderRequestDto updateOrderRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var updatedOrder = await mediator.Send(new UpdateOrderCommandRequest(updateOrderRequest.UserId, updateOrderRequest.ProductId, updateOrderRequest.Quantity, updateOrderRequest.TotalPrice,orderId)); ;

            if (updatedOrder == null)
            {
                return NotFound("order not found or No updation is allowed on the order");
            }
            else
            {
                return Ok(updatedOrder);
            }
        }
        [HttpPut("ConfirmOrder")]
        public async Task<IActionResult> ConfirmOrder(Guid orderId)
        {
            var confirmedOrder = await mediator.Send(new ConfirmOrderCommandRequest(orderId));
            if (confirmedOrder == null)
            {
                return BadRequest("Order Not Found");
            }
            return Ok(confirmedOrder);
        }
        [HttpDelete]
        public async Task<IActionResult> DeleteOrder(string orderId)
        {
            var deletedOrder = await mediator.Send(new DeleteOrderCommandRequest(orderId));
            if (deletedOrder == null)
            {
                return NotFound();
            }
            return Ok(deletedOrder);
        }
    }
}
