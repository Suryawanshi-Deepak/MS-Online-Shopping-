﻿using AggregatorApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace AggregatorApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AggregatorController : ControllerBase
    {

        private readonly AggregatorService _aggregatorService;

        public AggregatorController(AggregatorService aggregatorService)
        {
            _aggregatorService = aggregatorService;
        }

        [HttpPost("placeOrderAndShip")]
        public async Task<IActionResult> PlaceOrderAndShip(Guid orderId)
        {
            var result = await _aggregatorService.PlaceOrderAndShip(orderId);
            if (result == null)
            {
                return StatusCode(500, "Internal Server Error");

            }
            return Ok(result);
        }
    }
}
