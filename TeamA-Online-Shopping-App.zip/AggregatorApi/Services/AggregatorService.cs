﻿using AggregatorApi.Model;
using Newtonsoft.Json;
using ShippingApi.Models.Domain;
using System.Text;

namespace AggregatorApi.Services
{
    public class User
    {
        public Guid UserId { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public string? ContactNo { get; set; }
        public string? Address { get; set; }

    }
        public class AggregatorService
    {
        private readonly IHttpClientFactory httpClientFactory;

        public AggregatorService(IHttpClientFactory _httpClient)
        {
            httpClientFactory = _httpClient;
            
        }
        public async Task<ShippingDetail> PlaceOrderAndShip(Guid orderId)
        {
            try
            {
                var orderHttpClient = httpClientFactory.CreateClient("OrderApiClient");
                var orderResponse = await orderHttpClient.PutAsync("/api/Order/ConfirmOrder?orderId="+orderId,null);
                if (orderResponse.IsSuccessStatusCode)
                {
                    var orderResponseContent = await orderResponse.Content.ReadAsStringAsync();
                    var confirmedOrderData = JsonConvert.DeserializeObject<ConfirmedOrderDetails>(orderResponseContent);
                    var userHttpClient = httpClientFactory.CreateClient("UserApiClient");
                    var userDetail = await userHttpClient.GetAsync("/api/User/userid?userid=" + Guid.Parse("24B6CF61-A9FA-4DAC-ED01-08DBE6AC31A0"));
                    var userResponseContent = await userDetail.Content.ReadAsStringAsync();
                    var userData = JsonConvert.DeserializeObject<User>(userResponseContent);
                    ShippingDetail shippingDetail = new ShippingDetail
                    {
                        ProductId = confirmedOrderData!.ProductId,
                        UserID = confirmedOrderData.UserId,
                        ContactNo = userData.ContactNo,
                        NumberOfItems = confirmedOrderData.Quantity,
                        AddressDetails = userData.Address

                    };
                    string jsonShipping = JsonConvert.SerializeObject(shippingDetail);
                    var contentShipping = new StringContent(jsonShipping, Encoding.UTF8, "application/json");
                    var shippingHttpClient = httpClientFactory.CreateClient("ShippingApiClient");
                    var shippingResponse = await shippingHttpClient.PostAsync("/api/ShippingDetails", contentShipping);
                    var responseContent = await shippingResponse.Content.ReadAsStringAsync();
                    var responseObject = JsonConvert.DeserializeObject<ShippingDetail>(responseContent);

                    if (shippingResponse.IsSuccessStatusCode)
                    {
                        return(responseObject);
                    }
                    else
                    {
                        throw new Exception($"Error in Shipping API. Status Code: {shippingResponse.StatusCode}");
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
            return null;            
        }
    }
}
