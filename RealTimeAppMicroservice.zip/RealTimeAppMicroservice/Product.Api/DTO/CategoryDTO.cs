﻿using System.ComponentModel.DataAnnotations;

namespace Product.Api.DTO
{
    public class CategoryDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
