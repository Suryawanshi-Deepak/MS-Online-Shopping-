﻿using Microsoft.EntityFrameworkCore;
using Product.Api.Data;
using Product.Api.DTO;
using Product.Api.Mapper;

namespace Product.Api.Services.implimentations
{
    public class ProductService : IProductService
    {
        private readonly ProductDbContext  _context;
        public ProductService(ProductDbContext context)
        {
            _context = context;
        }
        public async Task<ProductDTO> CreateUpadteProductAsync(ProductDTO productDTO)
        {
            var product = ModelConverter.DTOtoModel(productDTO);
            if (product.Id>0) 
            {
                _context.Products.Update(product);
            }
            else
            {
                _context.Products.Add(product);
            }
            await _context.SaveChangesAsync();
            var dtoProduct = ModelConverter.ModeltoDTO(product);
            return dtoProduct;
        }

        public async Task<bool> DeleteProductAsync(int id)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == id);
            if (product == null) 
            {
                return false;
            }
            _context.Products.Remove(product);  
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<ProductDTO>> GetAllProduct()
        {
            var products = await _context.Products.Select(product=>
            ModelConverter.ModeltoDTO(product)).ToListAsync();
            return products;
        }

        public async Task<ProductDTO> GetProductById(int id)
        {
            var product = await _context.Products.Select(product=>
            ModelConverter.ModeltoDTO(product)).FirstOrDefaultAsync();
            return product;
        }
    }
}
