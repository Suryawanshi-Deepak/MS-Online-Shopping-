﻿namespace Product.Api.Services.implimentations
{
    public class CategoryService : ICategoryService
    {
        public Task<IEnumerable<CategoryDTO> GetAllCategory()
        {
            throw new NotImplementedException();
        }

        public Task<CategoryDTO> GetCategoryById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
