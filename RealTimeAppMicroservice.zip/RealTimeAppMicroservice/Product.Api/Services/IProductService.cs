﻿using Product.Api.DTO;

namespace Product.Api.Services
{
    public interface IProductService
    {
        Task<IEnumerable<ProductDTO>> GetAllProduct();
        Task<ProductDTO> GetProductById(int id);
        Task<ProductDTO> CreateUpadteProductAsync(ProductDTO productDTO);
        Task<bool> DeleteProductAsync(int id);

    }
}
