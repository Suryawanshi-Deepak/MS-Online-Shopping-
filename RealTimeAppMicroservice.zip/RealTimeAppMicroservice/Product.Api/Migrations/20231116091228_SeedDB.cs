﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Product.Api.Migrations
{
    /// <inheritdoc />
    public partial class SeedDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Products_categories_CategoryId",
                table: "Products");

            migrationBuilder.DropPrimaryKey(
                name: "PK_categories",
                table: "categories");

            migrationBuilder.RenameTable(
                name: "categories",
                newName: "Categories");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Categories",
                table: "Categories",
                column: "Id");

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Title" },
                values: new object[] { 1, "Camera" });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CategoryId", "Description", "ImageUrl", "Price", "Title" },
                values: new object[,]
                {
                    { 1, 1, "Fcusing system with extra focus with high HD Feature", "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.flipkart.com%2Fnikon-z5-mirrorless-camera-24-200-mm%2Fp%2Fitmfe9f611e9889f&psig=AOvVaw0CRnmYKa-12e6AFnL4i1QI&ust=1700202141656000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCPD97Nbwx4IDFQAAAAAdAAAAABAL", 1089m, "Nikon Digital  Camera  Z 5 kit with extra feature" },
                    { 2, 1, "Fcusing extra focus with high HD Feature", "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.in%2FRenewed-Canon-Digital-Camera-S18-55%2Fdp%2FB07L28DQPN&psig=AOvVaw0CRnmYKa-12e6AFnL4i1QI&ust=1700202141656000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCPD97Nbwx4IDFQAAAAAdAAAAABAS", 1079m, "Nikon Digital  Camera  Z 3 kit with extra feature" }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_Products_Categories_CategoryId",
                table: "Products",
                column: "CategoryId",
                principalTable: "Categories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Products_Categories_CategoryId",
                table: "Products");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Categories",
                table: "Categories");

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.RenameTable(
                name: "Categories",
                newName: "categories");

            migrationBuilder.AddPrimaryKey(
                name: "PK_categories",
                table: "categories",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Products_categories_CategoryId",
                table: "Products",
                column: "CategoryId",
                principalTable: "categories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
