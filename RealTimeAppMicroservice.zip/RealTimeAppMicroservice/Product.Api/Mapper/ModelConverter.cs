﻿using Product.Api.DTO;

namespace Product.Api.Mapper
{
    public static class ModelConverter
    {
        public static Product.Api.Entities.Product DTOtoModel(ProductDTO model)
        {
            return new Product.Api.Entities.Product
            {
                Id = model.Id,
                Title = model.Title,
                Description = model.Description,
                Price = model.Price,
                CategoryId = model.CategoryId,
                ImageUrl = model.ImageUrl,
            };
        }


        public static Product.Api.Entities.Category DTOtoModel(CategoryDTO model)
        {
            return new Product.Api.Entities.Category
            {
                Id = model.Id,
                Title = model.Title,
               
            };
        }
        public static ProductDTO ModeltoDTO(Product.Api.Entities.Product model)
        {
            return new ProductDTO
            {
                Id = model.Id,
                Title = model.Title,
                Description = model.Description,
                Price = model.Price,
                CategoryId = model.CategoryId,
                ImageUrl = model.ImageUrl
            };
        }

        public static CategoryDTO ModeltoDTO(Product.Api.Entities.Category model)
        {
            return new CategoryDTO
            {
                Id = model.Id,
                Title = model.Title,
            };
        }
    }
}
