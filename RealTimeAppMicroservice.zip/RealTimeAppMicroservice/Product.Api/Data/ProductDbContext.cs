﻿using Microsoft.EntityFrameworkCore;
using Product.Api.Entities;

namespace Product.Api.Data
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {

        }
        public DbSet<Product.Api.Entities.Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Product.Api.Entities.Category>().HasData(
                new Entities.Category
                {
                    Id = 1,
                    Title = "Camera"



                });




            modelBuilder.Entity<Product.Api.Entities.Product>().HasData(
                new Entities.Product
                {
                    Id = 1,
                    Title = "Nikon Digital  Camera  Z 5 kit with extra feature",
                    Price = 1089,
                    Description = "Fcusing system with extra focus with high HD Feature",
                    ImageUrl = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.flipkart.com%2Fnikon-z5-mirrorless-camera-24-200-mm%2Fp%2Fitmfe9f611e9889f&psig=AOvVaw0CRnmYKa-12e6AFnL4i1QI&ust=1700202141656000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCPD97Nbwx4IDFQAAAAAdAAAAABAL",
                    CategoryId = 1


                });
            modelBuilder.Entity<Product.Api.Entities.Product>().HasData(
           new Entities.Product
           {
                    Id = 2,
                    Title = "Nikon Digital  Camera  Z 3 kit with extra feature",
                    Price = 1079,
                    Description = "Fcusing extra focus with high HD Feature",
                    ImageUrl = "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.in%2FRenewed-Canon-Digital-Camera-S18-55%2Fdp%2FB07L28DQPN&psig=AOvVaw0CRnmYKa-12e6AFnL4i1QI&ust=1700202141656000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCPD97Nbwx4IDFQAAAAAdAAAAABAS",
                    CategoryId = 1
           });



        }
    }
}
